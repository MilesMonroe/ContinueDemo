package com.example.ft16demo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class gpio {
	public static void gpio_control(int gpio,int mode){
		try
        {
			String file_name = new String("/sys/class/gpio/gpio"+gpio+"/value");
			File file = new File(file_name);
			if(file.exists()==false){
				file_name = new String("/sys/class/gpiocontrol/gpiocontrol/gpiocontrol"+gpio);
				file = new File(file_name);
			}
			
			FileWriter localFileWriter = new FileWriter(file);
		    if(mode==1)
		       localFileWriter.write("1");
		    else if(mode==0)
		       localFileWriter.write("0");
		    localFileWriter.close();
	    }
        catch (IOException localIOException)
        {
            localIOException.printStackTrace();
        }
	}
	public static boolean gpio_read(int gpio){
		try
        {
			String file_name = new String("/sys/class/gpio/gpio"+gpio+"/value");
			File file = new File(file_name);
			if(file.exists()==false){
				file_name = new String("/sys/class/gpiocontrol/gpiocontrol/gpiocontrol"+gpio);
				file = new File(file_name);
			}
			
			FileReader localFileRead = new FileReader(file);
			char[] ch = new char[1];
			localFileRead.read(ch);
			localFileRead.close();
			if(ch[0]=='1') return true;
			return false;
			
	    }
        catch (IOException localIOException)
        {
            localIOException.printStackTrace();
        }
		return false;
	}
}
