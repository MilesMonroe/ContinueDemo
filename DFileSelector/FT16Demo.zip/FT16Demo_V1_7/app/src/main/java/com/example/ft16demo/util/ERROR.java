package com.example.ft16demo.util;

public class ERROR {
    public static final int SUCCESS          = 0;
    public static final int ERR_DEVICE       = -101;
    public static final int ERR_PARAM        = -102;
    public static final int ERR_NONSUPPORT   = -103;
    public static final int ERR_FAIL         = -104;
    public static final int ERR_TIMEOUT      = -105;
    public static final int ERR_TESTING      = -106;//测试过程中
    public static final int ERR_CANCEL       = -106;//手动取消
    public static final int ERR_PARSE        = -107;//解析出错

}
