package com.duke.dfileselector.provide.dateFormat;

/**
 * @author duke
 * @dateTime 2018-09-08 14:52
 * @description
 */
public abstract class FileDateProvide {
    public abstract String formatDate(long modifyTime);
}
