package com.example.ft16demo;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.duke.dfileselector.activity.DefaultSelectorActivity;
import com.duke.dfileselector.util.FileSelectorUtils;
import com.example.ft16demo.util.LogHelper;

import java.io.IOException;
import java.util.ArrayList;

import static com.example.ft16demo.gpio.gpio_read;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Switch mSwitchPower;
    private SerialHelper mSerialHelper;
    private Button btnGetSPPmac,btnGetBLEmac,btnGetSPPName,btnSetSPPName,btnGetBLEName,btnSetBLEName,btnSetBaut1,btnSetBaut2,btnDisconnect,btnStatus,
                   btnSelectFile;
    private TextView tvFilePath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }
    private void initView(){
        mSwitchPower = (Switch)findViewById(R.id.switch_ft16);
        //1、蓝牙EN键
        mSwitchPower.setChecked(gpio_read(124));
        mSwitchPower.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    gpio.gpio_control(124,1);//BT_EN
                    //当蓝牙在连接状态，CMD_DATA_SWITCH管脚才起作用,0：低，命令模式;1：高，透传模式;
                    //当蓝牙在非连接状态，都在命令模式
                    if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,1);//CMD_DATA_SWITCH(DATA MODE)
                    else gpio.gpio_control(63,1);//CMD_DATA_SWITCH(DATA MODE)
                    //LowPower管脚暂且飞线为LINK_GPIO4；0:蓝牙未连接; 1；蓝牙已连接
                    if( Build.MODEL.equals("US835")) gpio.gpio_control(1129,1);//BT_LowPower(Exit LowPower)
                    else gpio.gpio_control(129,1);//BT_LowPower(Exit LowPower)
                } else {
                    gpio.gpio_control(124,0);
                }
            }
        });
        //2、SPP EN键
        ((Switch)findViewById(R.id.switch_spp)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                       public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                           byte[] info = new byte[100];
                           if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,0);//CMD_DATA_SWITCH(DATA MODE)
                           else gpio.gpio_control(63,0);//CMD_DATA_SWITCH(DATA MODE)
                           mSerialHelper = new SerialHelper("/dev/ttyXRM0",230400);
                           try {
                               mSerialHelper.open();
                               mSerialHelper.send(("AT+SPP="+(isChecked?"1":"0")+"\r\n").getBytes());
                               if(mSerialHelper.RecvInfo(info)!=0) Toast.makeText(MainActivity.this, "设置可能失败，请尝试设置230400波特率" , Toast.LENGTH_SHORT).show();
                               mSerialHelper.close();
                           }catch (IOException e){
                               e.printStackTrace();
                           }
                           if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,1);//CMD_DATA_SWITCH(DATA MODE)
                           else gpio.gpio_control(63,1);//CMD_DATA_SWITCH(DATA MODE)

                       }});
        //3、BLE EN键
        ((Switch)findViewById(R.id.switch_ble)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                byte[] info = new byte[100];
                if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,0);//CMD_DATA_SWITCH(DATA MODE)
                else gpio.gpio_control(63,0);//CMD_DATA_SWITCH(DATA MODE)
                mSerialHelper = new SerialHelper("/dev/ttyXRM0",230400);
                try {
                    mSerialHelper.open();
                    mSerialHelper.send(("AT+BLE="+(isChecked?"1":"0")+"\r\n").getBytes());
                    if(mSerialHelper.RecvInfo(info)!=0) Toast.makeText(MainActivity.this, "设置可能失败，请尝试设置230400波特率" , Toast.LENGTH_SHORT).show();
                    mSerialHelper.close();
                }catch (IOException e){
                    e.printStackTrace();
                }
                if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,1);//CMD_DATA_SWITCH(DATA MODE)
                else gpio.gpio_control(63,1);//CMD_DATA_SWITCH(DATA MODE)

            }});

        btnGetSPPmac = (Button)findViewById(R.id.btn_GetSPPMac);
        btnGetSPPmac.setOnClickListener(this);
        btnGetBLEmac = (Button)findViewById(R.id.btn_GetBLEMac);
        btnGetBLEmac.setOnClickListener(this);

        btnGetSPPName = (Button)findViewById(R.id.btn_ReadSPPName);
        btnGetSPPName.setOnClickListener(this);
        btnSetSPPName = (Button)findViewById(R.id.btn_SetSPPName);
        btnSetSPPName.setOnClickListener(this);

        btnGetBLEName = (Button)findViewById(R.id.btn_ReadBLEName);
        btnGetBLEName.setOnClickListener(this);
        btnSetBLEName = (Button)findViewById(R.id.btn_SetBLEName);
        btnSetBLEName.setOnClickListener(this);

        btnSetBaut1 = (Button)findViewById(R.id.btn_SetBaud1);
        btnSetBaut1.setOnClickListener(this);
        btnSetBaut2 = (Button)findViewById(R.id.btn_SetBaud2);
        btnSetBaut2.setOnClickListener(this);

        btnDisconnect = (Button)findViewById(R.id.btn_Disconnect);
        btnDisconnect.setOnClickListener(this);
        btnStatus = (Button)findViewById(R.id.btn_getStatus);
        btnStatus.setOnClickListener(this);

        btnSelectFile = (Button)findViewById(R.id.btn_selectfile);
        btnSelectFile.setOnClickListener(this);

        tvFilePath = findViewById(R.id.tv_showfilepath);

        ((Button)findViewById(R.id.btn_setBLEMac)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_setSPPMac)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_closeFC)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_openFC)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_FCStatus)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_version)).setOnClickListener(this);

        ((Button)findViewById(R.id.btn_setUUID)).setOnClickListener(this);
        ((Button)findViewById(R.id.btn_getUUID)).setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        byte[] info = new byte[100];
        int ret = -1;
        if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,0);//CMD_DATA_SWITCH(DATA MODE)
        else gpio.gpio_control(63,0);//CMD_DATA_SWITCH(DATA MODE)
        mSerialHelper = new SerialHelper("/dev/ttyXRM0",230400);
        try {
            mSerialHelper.open();
            switch (v.getId()) {
                case R.id.btn_GetSPPMac:
                    mSerialHelper.send("AT+MAC?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0)
                        ((EditText)findViewById(R.id.tv_showSPPMac)).setText(new String(info).substring(5));
                    else Toast.makeText(this, "获取失败，请尝试设置230400波特率" , Toast.LENGTH_SHORT).show();
                    break;
                case R.id.btn_setSPPMac:
                    Log.d("Set BtSPPMac",((EditText)findViewById(R.id.tv_showSPPMac)).getText()+" length"+((EditText)findViewById(R.id.tv_showSPPMac)).getText().length());
                    mSerialHelper.send(("AT+MAC="+((EditText)findViewById(R.id.tv_showSPPMac)).getText()+"\r\n").getBytes());
                    break;
                case R.id.btn_setBLEMac:
                    Log.d("Set BtBLEMac",((EditText)findViewById(R.id.tv_showBLEMac)).getText()+" length"+((EditText)findViewById(R.id.tv_showBLEMac)).getText().length());
                    mSerialHelper.send(("AT+LEMAC="+((EditText)findViewById(R.id.tv_showBLEMac)).getText()+"\r\n").getBytes());
                    break;
                case R.id.btn_GetBLEMac:
                    mSerialHelper.send("AT+LEMAC?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0)
                        ((EditText)findViewById(R.id.tv_showBLEMac)).setText(new String(info).substring(7));
                    else Toast.makeText(this, "获取失败，请尝试设置230400波特率" , Toast.LENGTH_SHORT).show();
                    break;
                case R.id.btn_ReadBLEName:
                    mSerialHelper.send("AT+LENAME?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0)
                        ((EditText)findViewById(R.id.edit_BtBLEName)).setText(new String(info).substring(8));
                    else {
                        Toast.makeText(this, "获取失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btn_SetBLEName:
                    Log.d("Set BtBLEName",((EditText)findViewById(R.id.edit_BtBLEName)).getText()+" length"+((EditText)findViewById(R.id.edit_BtBLEName)).getText().length());
                    mSerialHelper.send(("AT+LENAME="+((EditText)findViewById(R.id.edit_BtBLEName)).getText()+"\r\n").getBytes());
                    break;
                case R.id.btn_ReadSPPName:
                    mSerialHelper.send("AT+DNAME?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0)
                        ((EditText)findViewById(R.id.edit_BtSPPName)).setText(new String(info).substring(7));
                    else {
                        Toast.makeText(this, "获取失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btn_getUUID:
                    mSerialHelper.send("AT+UUID?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0)
                        ((EditText)findViewById(R.id.tv_showUUID)).setText(new String(info).substring(6));
                    else {
                        Toast.makeText(this, "获取失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btn_setUUID:
                    mSerialHelper.send("AT+SERV=FF01\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if (ret == 0) {
                    } else {
                        Toast.makeText(this, "设置服务UUID失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    mSerialHelper.send("AT+NOTIFY=FF02\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if (ret == 0) {
                    } else {
                        Toast.makeText(this, "设置NOTIFY UUID失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    mSerialHelper.send("AT+WRITE=FF03\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if (ret == 0) {
                    } else {
                        Toast.makeText(this, "设置write UUID失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    break;
                case R.id.btn_SetSPPName:
                    Log.d("Set BtSPPName",((EditText)findViewById(R.id.edit_BtSPPName)).getText()+" length"+((EditText)findViewById(R.id.edit_BtSPPName)).getText().length());
                    mSerialHelper.send(("AT+DNAME="+((EditText)findViewById(R.id.edit_BtSPPName)).getText()+"\r\n").getBytes());
                    break;
                case R.id.btn_SetBaud1:
                    mSerialHelper.close();
                    mSerialHelper = new SerialHelper("/dev/ttyXRM0",230400);
                    mSerialHelper.open();
                    mSerialHelper.send("AT+URATE=115200\r\n".getBytes());
                    break;
                case R.id.btn_SetBaud2:
                    mSerialHelper.close();
                    mSerialHelper = new SerialHelper("/dev/ttyXRM0",115200);
                    mSerialHelper.open();
                    mSerialHelper.send("AT+URATE=230400\r\n".getBytes());
                    break;
                case R.id.btn_Disconnect:
                    mSerialHelper.send("AT+DISC=1\r\n".getBytes());
                    break;
                case R.id.btn_getStatus:
                    Toast.makeText(this, gpio_read(2129)?"蓝牙已连接":"蓝牙未连接" , Toast.LENGTH_SHORT).show();
                    ret = 0;
                    break;
                case R.id.btn_closeFC:
                    mSerialHelper.send("AT+FC=0\r\n".getBytes());
                    break;
                case R.id.btn_openFC:
                    mSerialHelper.send("AT+FC=1\r\n".getBytes());
                    break;
                case R.id.btn_FCStatus:
                    mSerialHelper.send("AT+FC?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if(ret==0) {
                        if("1".equals(new String(info).substring(4,5)))
                            Toast.makeText(this, "流控已打开", Toast.LENGTH_SHORT).show();
                        else if("0".equals(new String(info).substring(4,5))) Toast.makeText(this, "流控未打开", Toast.LENGTH_SHORT).show();
                        else Toast.makeText(this, "其它错误:"+new String(info), Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(this, "获取失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btn_version:
                    mSerialHelper.send("AT+VER?\r\n".getBytes());
                    ret = mSerialHelper.RecvInfo(info);
                    if (ret == 0) {
                        Toast.makeText(this, "版本号:" + new String(info).substring(5), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "获取失败，请尝试设置230400波特率", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case R.id.btn_selectfile:
                    LogHelper.getInstance().w( "--->点击启动");
                    DefaultSelectorActivity.startActivity(this);//包含广播
                    break;

            }
            if(ret!=0){
                if(mSerialHelper.RecvInfo(info)!=0) Toast.makeText(this, "设置可能失败，请尝试设置230400波特率" , Toast.LENGTH_SHORT).show();
            }
            mSerialHelper.close();
        }catch (IOException e){
            e.printStackTrace();
        }
        if( Build.MODEL.equals("US835")) gpio.gpio_control(1063,1);//CMD_DATA_SWITCH(DATA MODE)
        else gpio.gpio_control(63,1);//CMD_DATA_SWITCH(DATA MODE)
    }

    //-----------------------------Handler处理------------------------------------
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            Bundle bundle = msg.getData();


            switch ((String) msg.obj) {

                case "filepath":
                    String filepath = null;
                    filepath = bundle.getString("filepath");
                    LogHelper.getInstance().w("filepath="+filepath);
                    //Time刷新
                    tvFilePath.setText("filepath: "+filepath);
                    break;


                default:
                    break;
            }

        }
    };

    //提示信息
    protected void showHandlerMsg(String operation, Bundle bundle) {
        Message msg = new Message();
        msg.obj = operation;
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    //-----------------------------文件选择相关的操作------------------------------------
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (context == null || intent == null) {
                return;
            }
            if (DefaultSelectorActivity.FILE_SELECT_ACTION.equals(intent.getAction())) {
                String selectFilePath=null;
                selectFilePath=printData(DefaultSelectorActivity.getDataFromIntent(intent));
                if(selectFilePath!=null){
                    Bundle bundle=new Bundle();
                    bundle.putString("filepath", selectFilePath);
                    //刷新界面
                    showHandlerMsg("filepath", bundle);
                }

            }
        }
    };


    private boolean isRegister=false;
    private IntentFilter intentFilter = new IntentFilter(DefaultSelectorActivity.FILE_SELECT_ACTION);

    @Override
    protected void onResume() {
        super.onResume();
        if (!isRegister) {
            registerReceiver(receiver, intentFilter);
            isRegister = true;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isRegister) {
            unregisterReceiver(receiver);
            isRegister = false;
        }
    }

    private String printData(ArrayList<String> list) {
        if (FileSelectorUtils.isEmpty(list)) {
            return null;
        }
        int size = list.size();

        LogHelper.getInstance().w( "--->获取到数据-开始 size = " + size);
        StringBuffer stringBuffer = new StringBuffer("选中的文件：\r\n");
        for (int i = 0; i < size; i++) {
            LogHelper.getInstance().w( (i + 1) + " = " + list.get(i));
            stringBuffer.append(list.get(i));
            stringBuffer.append("\r\n");
        }
        Toast.makeText(this, stringBuffer.toString(), Toast.LENGTH_SHORT).show();
        LogHelper.getInstance().w( "--->获取到数据-结束");
        return stringBuffer.toString();
    }
}
